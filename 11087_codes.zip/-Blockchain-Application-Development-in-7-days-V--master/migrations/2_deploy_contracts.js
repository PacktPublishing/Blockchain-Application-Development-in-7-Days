var Gaming = artifacts.require("./Gaming.sol");

module.exports = function(deployer) {
  deployer.deploy(Gaming);
};

import keyMirror from 'keymirror'

export default keyMirror({
  SET_PROVIDER: null
})
